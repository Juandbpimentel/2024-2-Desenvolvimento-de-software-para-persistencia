from pydantic import BaseModel, Field
from typing import List, Optional

from models.classe import Classe
from models.guilda import Guilda
from models.skills import Skill


class Personagem(BaseModel):
    id: Optional[int] = Field(default=None)
    nome: str
    nivel: int
    poder: int
    xp_atual: int
    xp_proximo_nivel: int
    hp_atual: int
    hp_max: int
    mana_atual: int
    mana_max: int
    forca: int
    defesa: int
    classe_id: int
    guilda_id: Optional[int] = None
    classe: Optional["Classe"] = None
    guilda: Optional["Guilda"] = None
    skills: List["Skill"] = Field(default_factory=list)