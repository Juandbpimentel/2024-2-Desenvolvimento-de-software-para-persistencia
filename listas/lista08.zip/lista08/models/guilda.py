from pydantic import BaseModel, Field
from typing import List, Optional

from models.personagem import Personagem


class Guilda(BaseModel):
    id: Optional[int] = Field(default=None)
    nome: str
    descricao: str
    dono_id: Optional[int] = None
    dono: Optional["Personagem"] = None
    personagens: List["Personagem"] = Field(default_factory=list)