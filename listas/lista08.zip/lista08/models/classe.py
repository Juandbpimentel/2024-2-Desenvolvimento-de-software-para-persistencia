from pydantic import BaseModel, Field
from typing import List, Optional

from models.personagem import Personagem
from models.skills import Skill


class Classe(BaseModel):
    id: Optional[int] = Field(default=None)
    nome: str
    descricao: str
    escala_dano_por_nivel: int
    escala_vida_por_nivel: int
    escala_mana_por_nivel: int
    personagens: List["Personagem"] = Field(default_factory=list)
    skills: List["Skill"] = Field(default_factory=list)