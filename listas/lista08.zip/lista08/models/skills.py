from pydantic import BaseModel, Field
from typing import List, Optional

from models.classe import Classe


class Skill(BaseModel):
    id: Optional[int] = Field(default=None)
    nome: str
    descricao: str
    nivel_necessario: int
    dano_base_da_skill: Optional[int] = None
    cura_base_da_skill: Optional[int] = None
    custo_de_mana_base: Optional[int] = None
    custo_de_vida_base: Optional[int] = None
    classe_id: int
    classe: Optional["Classe"] = None